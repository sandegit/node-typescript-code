export class UserVerificationCode {
    userId: string;
    verificationCode: string;
}