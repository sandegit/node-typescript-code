import { User } from "./user";

export class Ranking {
    totalPoints: number;
    rounds?:number;
    user: User;
}