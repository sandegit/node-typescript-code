export enum GolfDivision {
    Champ = "CHAMP",
    Celebrity = "CELEBRITY",
    ProfessionalGolfer = "PROFESSIONAL_GOLFER",
    PGAPro = "PGA Pro",
    TourPlayer = "PROFESSIONAL_GOLFER"
}