// Strokes
export class Score {
    hole: number;
    score: number;
    points:number;
}