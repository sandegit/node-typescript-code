export class ProfileUrlLink {
    _id: string;
//    userId: string;
//    linkNameId: string;
    linkName: string;
    linkUrl: string;
}