export class GolfHole {
    hole: number;
    par: number;
}