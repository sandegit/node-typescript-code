export class Group {
    size: number;
    maxGroups: number;
}