export enum AccountStatus {
    Active = "ACTIVE",
    Disabled = "DISABLED"
}