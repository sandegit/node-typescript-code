export enum GolfClubMembership {
    Private = "PRIVATE",
    SemiPrivate = "SEMI-PRIVATE",
    Public = "PUBLIC",
    Resort = "RESORT",
    Military = "MILITARY"
}