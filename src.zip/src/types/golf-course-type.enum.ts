export enum GolfCourseType {
    Parkland = "PARKLAND",
    Desert = "DESERT",
    Links = "LINKS"
}