export enum GolfCourseGuestPolicy {
    Open = "OPEN",
    Closed = "CLOSED"
}