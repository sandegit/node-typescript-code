/**
 * Copyright (c) 2020 Codev Technologies (Pty) Ltd. All rights reserved.
 */

export class RangeFilter {
    constructor(public start: any, public end: any) {}
}