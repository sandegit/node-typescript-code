/**
 * Copyright (c) 2020 Codev Technologies (Pty) Ltd. All rights reserved.
 */

export class GreaterThanOrEqualFilter {
    constructor(public value: any) {}
}