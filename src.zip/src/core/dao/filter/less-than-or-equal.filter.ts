/**
 * Copyright (c) 2020 Codev Technologies (Pty) Ltd. All rights reserved.
 */

export class LessThanOrEqualFilter {
    constructor(public value: any) {}
}