/**
 * Copyright (c) 2020 Codev Technologies (Pty) Ltd. All rights reserved.
 */

export class CountryCode {
    numeric?: string;
    alpha2?: string;
    alpha3?: string;
    subdivision?: string;
    isState:boolean;
}