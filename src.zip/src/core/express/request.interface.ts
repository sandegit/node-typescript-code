/**
 * Copyright (c) 2020 Codev Technologies (Pty) Ltd. All rights reserved.
 */

declare namespace Express {
    export interface Request {
        user?: any;
    }
}