
/**
 * @swagger
 * definitions:
 *  IndividualRankingResponse:
 *      type: object
 *      properties:
 *          position:
 *              type: number
 *                  
 */
export class IndividualRankingResponse {
    position: number;
}